# MASTER PROMPT — Integrate the Eight Calibration & Qualification Protocols into the Calibration Management System

## 1. Role and mission

Act as a senior software engineer, quality-systems architect, and GMP/GLP computerized-system implementation specialist.

Integrate the supplied eight-device Calibration & Qualification Protocol package into the existing Calibration Management System. Preserve the current application architecture, framework, database conventions, authentication/authorization model, visual language, and existing working features. Do not rebuild the application from scratch and do not make unrelated changes.

The required outcome is:
1. The eight supplied protocols are available in the system as the controlled protocol library.
2. Every device uses the same nine-step controlled validation workflow demonstrated in the supplied Polarimeter Validation screenshots.
3. A new system page named **“تعديل بيانات ومواصفات الأجهزة”** (Edit Equipment Data & Specifications) allows authorized users to edit equipment identity/profile data and technical specifications.
4. Equipment changes automatically propagate to all linked protocol displays and future validation runs, without silently changing historical or already-approved records.
5. The system preserves draft conflict safety, controlled snapshots, audit trails, review/approval gates, and PDF output.

## 2. Mandatory source package and device register

Use the eight protocol documents supplied in this package as the authoritative baseline for protocol-specific tests, test sequence, formulas, acceptance criteria, data fields, and source citations.

The eight devices are:

| Equipment | Protocol ID | Primary USP reference |
|---|---|---|
| HPLC — Shimadzu LC-2030 PLUS | CAL-QC-HPLC-001 | USP <621> |
| Polarimeter — Bellingham & Stanley ADP220 | CAL-QC-POL-001 | USP <781> |
| Analytical Balance — Sartorius ED224S | CAL-QC-BAL-001 | USP <41>, <1251> |
| Moisture Analyzer | CAL-QC-MOA-001 | USP <731> |
| Dissolution Tester | CAL-QC-DIS-001 | USP <711> |
| Disintegration Tester | CAL-QC-DISINT-001 | USP <701> |
| Refractometer — RFM340 | CAL-QC-REF-001 | USP <831> |
| UV-Visible Spectrophotometer | CAL-QC-UV-001 | USP <857>, <1857> |

Shared qualification lifecycle reference: USP <1058>. The supplied USA USP reference archive also includes <921>; do not substitute USP <921> for USP <731> in the Moisture Analyzer protocol. Use <921> only where the approved intended method actually concerns water determination.

### Source hierarchy and content preservation

- Preserve the tests, method steps, formulas, units, acceptance criteria, cautions, and source references in each supplied protocol.
- Do not invent missing instrument values, specifications, criteria, calibration dates, test results, signatures, or approvals.
- Do not convert “NOT SPECIFIED IN SUPPLIED USP SOURCE” into an assumed criterion.
- Do not silently replace a protocol criterion with a generic industry value.
- Where the protocol, equipment register, SOP, manufacturer manual, and pharmacopoeia appear to conflict, flag the conflict for controlled technical resolution. Display the source and rationale; never silently overwrite the approved protocol.
- The HPLC calibration record `HPLC.pdf` is the controlling primary reference for HPLC-specific recorded tests, setpoints, readings, calculations, and acceptance criteria, subject to applicable USA USP requirements. Preserve original values and document any justified adopted value and exact source.
- For the Analytical Balance, retain the current Rev.01 document and its explicit QA-pending status. Its USP <41> repeatability test requires at least ten readings; the historical six-reading record must not be accepted as satisfying that requirement.
- The supplied protocols may contain draft/review status metadata. Store document status accurately. The system must never imply that an instrument passed qualification merely because a protocol is loaded.

## 3. Required workflow — exactly nine steps for every device

Implement a consistent nine-step workflow for all eight devices, following the Polarimeter Validation UI shown in the supplied screenshots.

Use these exact step numbers and labels, in this order:

1. **Equipment Selection**
2. **Protocol**
3. **Accuracy**
4. **Repeatability**
5. **Linearity**
6. **Results**
7. **Review**
8. **Approval**
9. **PDF**

The horizontal stepper must display step number, label, completion/current/pending state, and allow navigation only according to the application's validation rules. Preserve the visual approach of the Polarimeter workflow: prominent title and status, horizontal numbered steps, clear warning banners, and a structured current-step panel.

### Step-specific behavior

**Step 01 — Equipment Selection**
- Select an equipment record from the existing Equipment Register.
- Populate equipment identity from the equipment master record.
- Display identity fields as read-only in the validation run.
- Include equipment name, Equipment ID, manufacturer, model, serial number, applicable SOP/form number, department, location, and equipment status where those fields exist.
- Clearly display “Not available in the current equipment profile” for missing values; do not fabricate them.
- A validation run must retain the exact equipment-profile snapshot used when the run was created.

**Step 02 — Protocol**
- Select the current effective protocol for the selected equipment.
- Display protocol ID, revision, status, effective date, applicable references, and protocol verification state.
- Load the tests, formulas, units, acceptance criteria, and required data fields from the linked protocol definition.
- If criteria have not been verified against the applicable SOP/source, show a blocking or warning state equivalent to the Polarimeter screenshot: a draft may be saved, but formal approval must remain blocked until verification is completed.
- A protocol mismatch, invalid payload, or unresolved server/local draft conflict must never be overwritten automatically.

**Step 03 — Accuracy**
- Render the Accuracy test form defined for the selected device.
- Use protocol-defined measurement points, reference standards, units, calculations, and acceptance criteria.
- Capture original/raw readings separately from calculated values.
- Do not force a universal accuracy test if the device protocol defines a different applicable test structure. If Accuracy is not applicable, show “Not Applicable” with a documented justification and reviewer confirmation; do not silently skip the step.

**Step 04 — Repeatability**
- Render the device-specific repeatability test and number of required replicates from its protocol.
- Capture each original reading as a separate immutable data point.
- Calculate only using the formula defined by the protocol.
- Enforce minimum replicate count and protocol-specific acceptance limits.
- If not applicable, require a documented justification and reviewer confirmation.

**Step 05 — Linearity**
- Render the device-specific linearity test, points, settings, formula, and criterion from its protocol.
- Some devices may have additional or differently named tests. Keep the common nine-step navigation, but place all protocol-specific tests in the most relevant test section or a clearly labelled sub-section. Do not delete any test from the protocol.
- If linearity is not applicable, require a documented justification and reviewer confirmation.

**Step 06 — Results**
- Present a consolidated summary of every test, raw-data completeness, calculated results, acceptance criteria, units, pass/fail/not-applicable status, and deviations.
- Distinguish measured values from calculated values and imported historical data.
- A result cannot be marked PASS unless the required raw data and calculation are present and the protocol criterion is verified.
- Any missing result, failed criterion, unresolved deviation, or unverified protocol condition must prevent formal approval as applicable.

**Step 07 — Review**
- Provide technical review of source data, calculations, protocol revision, equipment snapshot, reference standards, deviations, and ALCOA+ data-integrity completeness.
- Record reviewer identity, date/time, comments, and review outcome.
- Any edit after review invalidates the review state and requires re-review.

**Step 08 — Approval**
- Provide role-based approval by authorized personnel only.
- Enforce segregation of duties where the current system's role model supports it.
- Approval is blocked if required tests are incomplete, criteria are unverified, deviations remain unresolved, or review is not complete.
- Store approver identity, timestamp, decision, comments, protocol revision, and equipment snapshot.
- Never auto-approve or simulate signatures.

**Step 09 — PDF**
- Generate a controlled, printable PDF report containing equipment identity snapshot, protocol ID/revision, source references, test procedures, original measurements, calculations, acceptance criteria, outcomes, deviations, review/approval signatures and timestamps, and document status.
- Include page numbers, report generation date, unique run/report ID, and controlled-document footer.
- Clearly mark drafts and unapproved reports as **DRAFT / NOT APPROVED**.
- PDF output must reproduce the approved run snapshot, not live equipment-master values that may have changed later.

### Additional protocol-specific tests

Accuracy, Repeatability, and Linearity are the common visible test steps required by the Polarimeter UI. Other protocol tests must remain available. Map them into the Results step or relevant test step as clearly labelled sub-tests, without omitting, renaming destructively, or changing their acceptance criteria. Examples include (where present in the relevant protocol): wavelength accuracy, photometric accuracy, stray light, dissolution mechanical checks, vessel dimensions, temperature, disintegration timing/temperature, moisture analyzer temperature performance, refractive-index verification, HPLC pump flow, injector precision, detector wavelength, carryover, gradient proportioning, and other protocol-defined checks.

Do not assume every example applies to every device. The selected device protocol determines the actual test inventory.

## 4. New page — “تعديل بيانات ومواصفات الأجهزة”

Add a dedicated page to the main navigation with this exact Arabic title:

**تعديل بيانات ومواصفات الأجهزة**

The page must allow authorized users to search/select any of the eight equipment records and edit the equipment profile and technical specifications.

### Editable equipment fields

Support, where applicable:

- Equipment name / instrument type
- Equipment ID
- Manufacturer
- Model
- Serial number
- Department
- Laboratory / location
- Equipment status
- Applicable SOP number and form number
- Capacity / measuring range
- Readability / resolution / scale interval
- Accuracy / uncertainty / repeatability / linearity specifications
- Operating range and environmental limits
- Wavelength / temperature / speed / flow / volume / timing ranges, as relevant
- Accessories and critical components
- Software / firmware version
- Calibration interval, last calibration date, next due date
- Manufacturer manual / datasheet reference and revision
- Notes and supporting document references

The field model must be extensible: different instrument classes have different specifications. Do not force balance-specific fields onto an HPLC or polarimeter. Use equipment-type-specific specification groups while retaining common identity fields.

### Edit, validation, and audit behavior

- Provide clear Edit, Save, and Cancel actions.
- Validate field type, unit, range, required fields, and duplicate Equipment IDs.
- Preserve units explicitly; never convert units silently.
- Record every change in an immutable audit history: field name, previous value, new value, user, date/time, reason for change, and change reference.
- Require a change reason for changes to critical specifications, SOP references, manufacturer/model/serial number, acceptance-related data, or calibration interval.
- Support optional attachment of controlled manufacturer datasheets/manuals and evidence.
- Show last-modified user and timestamp.
- Apply role-based permissions; ordinary users may view but only authorized roles may edit.
- Do not delete equipment records that are referenced by historical validation runs. Use inactive/retired status instead.

## 5. Automatic propagation to linked protocols — critical requirement

Changes saved on the equipment master page must automatically appear in the linked protocol's equipment-information fields and in future validation runs.

Implement this through a single normalized equipment master record and stable equipment/protocol relationships. Avoid duplicated hard-coded equipment specifications in separate UI components or static protocol text.

### Propagation rules

1. **Future runs:** Always use the latest effective equipment master data when a new validation run is created.
2. **Unapproved protocol drafts:** Update linked equipment-profile fields automatically, while preserving test methods and criteria. Record the change in audit history.
3. **Approved protocols:** Never silently mutate an approved controlled document. Create a new protocol revision/change request, preserve the prior revision, and require review/approval before it becomes effective.
4. **In-progress validation runs:** Preserve the equipment snapshot captured at run creation. Show a notification that newer equipment data exists; allow an authorized user to create a controlled update/restart only through the defined change process.
5. **Completed/approved historical runs:** Never change historical equipment data, readings, calculations, results, signatures, or PDFs.
6. **Test acceptance criteria:** Equipment specification changes must not automatically alter pharmacopoeial or approved SOP acceptance criteria. If a specification is used to derive a test limit, require explicit technical review, documented rationale, and a new approved protocol revision.
7. **Conflicts:** If server and local drafts differ, preserve both copies. Ask the user to choose the source or perform a field-level merge with a visible diff. Never discard either copy automatically.

### Data architecture

Use normalized entities or equivalent existing application structures:

- `Equipment` — stable identity and current effective profile.
- `EquipmentSpecification` — typed, unit-aware specifications linked to Equipment.
- `Protocol` — protocol identity and current effective revision.
- `ProtocolRevision` — immutable controlled revision and approval state.
- `ProtocolEquipmentLink` — relationship between protocol and equipment type/record.
- `ValidationRun` — run status and references to exact snapshots.
- `EquipmentSnapshot` — immutable equipment profile snapshot for a run.
- `ProtocolSnapshot` — immutable protocol/test/criteria snapshot for a run.
- `Measurement` — original raw measurement and metadata.
- `CalculatedResult` — calculated result, formula/version, units and status.
- `Deviation` — failure, OOT/OOS or other deviation record.
- `ReviewApproval` — reviewer/approver decisions and timestamps.
- `AuditEvent` — append-only audit trail.

Adapt names to the existing schema rather than introducing needless parallel tables. Use database migrations only when required, and preserve backward compatibility.

## 6. Draft conflict and data-preservation behavior

The supplied Polarimeter screenshots show these conditions:
- A server draft exists for a different or invalid protocol payload and is preserved.
- A draft conflict is detected; neither server nor local copy is overwritten.
- The user must choose which source to continue from.
- Protocol verification is pending; saving a draft remains available, while formal approval is blocked.

Implement and preserve these safeguards across all eight devices.

Never:
- Automatically overwrite server data with local data or vice versa.
- Automatically discard both copies.
- Treat an invalid or mismatched protocol payload as valid.
- Allow a protocol verification warning to be bypassed for formal approval.
- Lose measurement data when navigating between steps or refreshing.
- Modify historical approved snapshots when equipment master data changes.

## 7. User interface and usability

- Match the Polarimeter workflow visual language shown in the screenshots.
- Use consistent nine-step navigation for all devices.
- Show a clear run status such as Measurements in progress, Draft, Pending verification, Ready for review, Approved, or Rejected.
- Use warning banners for draft conflicts, protocol verification, missing equipment data, failed tests, and unresolved deviations.
- Show progress and completion state for each step.
- Preserve responsive behavior for desktop and mobile.
- Use the application's existing localization approach; keep the new page title exactly as specified in Arabic.
- Do not remove existing calibration, equipment register, reporting, deviation, audit, or export features.

## 8. Security, data integrity, and validation

- Preserve authentication and role-based access control.
- Validate all inputs server-side as well as client-side.
- Protect against unauthorized changes and duplicate submissions.
- Maintain ALCOA+ principles and attributable audit trails.
- Keep original measurements immutable after submission; corrections require an attributable correction event.
- Store formula identifiers/versions and calculation inputs so calculations can be reproduced.
- Use transactional persistence for multi-step save operations.
- Ensure a failed save does not create partial or contradictory records.
- Add automated tests for propagation, snapshots, conflict handling, permissions, step transitions, approval blocking, and PDF generation.

## 9. Implementation sequence

Work in controlled phases and inspect the repository before editing.

### Phase A — Repository and protocol inspection
1. Inspect the full repository, architecture, database, current Polarimeter workflow, equipment register, protocol storage, PDF generator, and test suite.
2. Read all eight supplied protocol documents completely.
3. Create an inventory of each protocol's tests, raw-data fields, formulas, units, criteria, references, revision, and verification status.
4. Identify any missing or conflicting equipment data. Do not invent values.
5. Report the files/components/database structures that will be changed before implementation.

### Phase B — Protocol library integration
1. Import the eight protocol documents and their metadata.
2. Map each protocol to the correct equipment type.
3. Preserve protocol revision and status.
4. Preserve the current Analytical Balance Rev.01 QA-pending status.
5. Ensure each protocol's actual test inventory is represented in the system.
6. Provide a protocol-to-device and protocol-to-source traceability view.

### Phase C — Unified nine-step workflow
1. Generalize the Polarimeter workflow into a reusable workflow component.
2. Apply it to all eight devices.
3. Implement device-specific test forms from the linked protocol definition.
4. Implement step validation, save/resume, results, review, approval, and PDF.
5. Preserve all draft-conflict and verification safeguards.

### Phase D — Equipment master editing page
1. Add “تعديل بيانات ومواصفات الأجهزة”.
2. Implement common equipment fields and type-specific specification groups.
3. Implement permissions, validation, change reasons, and audit history.
4. Link equipment master data to protocol displays and future validation runs.

### Phase E — Safe propagation and immutable snapshots
1. Implement future-run propagation.
2. Implement automatic update of unapproved draft profile fields.
3. Implement controlled protocol revision for approved documents.
4. Freeze snapshots for in-progress and historical runs.
5. Implement field-level conflict detection and safe merge/selection.

### Phase F — Testing and verification
Test at minimum:
- All eight equipment records can be selected.
- Each device follows steps 1 through 9 in the required order.
- Device-specific tests are neither omitted nor assigned another device's criteria.
- Raw readings persist across navigation and reload.
- Calculations reproduce protocol formulas.
- Missing/unverified criteria block approval.
- Failed tests and unresolved deviations block approval.
- Equipment edits appear in future runs and linked unapproved protocol fields.
- Approved and historical snapshots remain unchanged after master-data edits.
- Server/local draft conflicts preserve both copies.
- Role restrictions and audit trails work.
- PDFs contain the correct historical snapshot and controlled status.
- Existing application features and tests remain functional.

### Phase G — Delivery
Provide:
1. A concise implementation report.
2. List of changed/added files.
3. Database migrations and rollback notes, if any.
4. Protocol import inventory and mapping.
5. Test results with pass/fail evidence.
6. Known limitations and unresolved source-data gaps.
7. Build/package instructions.
8. Screenshots of the nine-step workflow for at least two different devices and the equipment-editing page.

## 10. Acceptance criteria — do not declare complete until all pass

- [ ] Eight protocols are imported and mapped to the correct equipment.
- [ ] Protocol-specific tests and criteria are preserved.
- [ ] All eight devices use the same nine-step workflow.
- [ ] Step labels and order match the Polarimeter screenshots exactly.
- [ ] Device-specific test content is dynamically rendered from the selected protocol.
- [ ] “تعديل بيانات ومواصفات الأجهزة” page exists and supports authorized editing.
- [ ] Equipment changes automatically propagate to linked unapproved protocol profile fields and future runs.
- [ ] Approved protocol revisions require controlled revision and approval.
- [ ] Validation runs and approved reports retain immutable equipment/protocol snapshots.
- [ ] Draft conflicts preserve server and local copies.
- [ ] Protocol verification warnings block formal approval.
- [ ] Audit history records all critical changes.
- [ ] PDF reports are generated from immutable run snapshots.
- [ ] Automated tests pass and existing features are not regressed.

## 11. Final operating instruction

Start by inspecting the actual repository and the complete supplied files. Do not assume a file, function, database table, framework, or existing workflow exists until you verify it.

Implement the work end-to-end in small, reviewable changes. Do not stop after writing a plan or mockup. Do not mark a phase complete without running its tests and reporting evidence.

If a source document does not provide a value or criterion, preserve it as missing/unverified and report it. Do not fabricate a value to make the interface appear complete.

**The required product is a working, tested integration into the existing Calibration Management System—not a visual prototype.**
