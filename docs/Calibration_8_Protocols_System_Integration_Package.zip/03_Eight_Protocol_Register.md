# Eight-Protocol Integration Register

| Device | Protocol ID | Source document in package | Primary USP |
|---|---|---|---|
| HPLC — Shimadzu LC-2030 PLUS | CAL-QC-HPLC-001 | CAL-QC-HPLC-001_HPLC_Protocol_Rev00_DRAFT.docx | <621> |
| Polarimeter — Bellingham & Stanley ADP220 | CAL-QC-POL-001 | CAL-QC-POL-001_Polarimeter_Protocol_Rev00_DRAFT.docx | <781> |
| Analytical Balance — Sartorius ED224S | CAL-QC-BAL-001 | CAL-QC-BAL-001_Analytical_Balance_Protocol_Rev01_DRAFT_QA_PENDING.docx | <41>, <1251> |
| Moisture Analyzer | CAL-QC-MOA-001 | CAL-QC-MOA-001_Moisture Analyzer_Protocol_Rev00_DRAFT.docx | <731> |
| Dissolution Tester | CAL-QC-DIS-001 | CAL-QC-DIS-001_Dissolution Tester_Protocol_Rev00_DRAFT.docx | <711> |
| Disintegration Tester | CAL-QC-DISINT-001 | CAL-QC-DISINT-001_Disintegration Tester_Protocol_Rev00_DRAFT.docx | <701> |
| Refractometer — RFM340 | CAL-QC-REF-001 | CAL-QC-REF-001_Refractometer_Protocol_Rev00_DRAFT.docx | <831> |
| UV-Visible Spectrophotometer | CAL-QC-UV-001 | CAL-QC-UV-001_UV-Visible Spectrophotometer_Protocol_Rev00_DRAFT.docx | <857>, <1857> |

Shared lifecycle reference: USP <1058>. The source USP archive also contains <921>; it must not be substituted for USP <731> unless the intended method is water determination.

## Status and control note
This is an integration package assembled from the supplied Rev.00 protocol archive and the available Analytical Balance Rev.01 file. The Balance Rev.01 remains explicitly QA-pending. The other seven source documents retain their original Rev.00 draft identifiers and contents; this package does not falsely relabel them as approved or invent approval signatures. The owner may direct the system integrator to treat this package as the selected baseline for implementation, but formal controlled-document approval and execution evidence remain separate quality-system events.
